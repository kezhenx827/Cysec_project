﻿namespace FinalProject
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbWeight = new System.Windows.Forms.Label();
            this.gbControl = new System.Windows.Forms.GroupBox();
            this.lbnum1 = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.lbTime = new System.Windows.Forms.Label();
            this.lbStatus = new System.Windows.Forms.Label();
            this.lbnum = new System.Windows.Forms.Label();
            this.lbTotal = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lbCurrentWeight = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gbControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbWeight
            // 
            this.lbWeight.AutoSize = true;
            this.lbWeight.Font = new System.Drawing.Font("標楷體", 25.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbWeight.Location = new System.Drawing.Point(354, 54);
            this.lbWeight.Name = "lbWeight";
            this.lbWeight.Size = new System.Drawing.Size(276, 42);
            this.lbWeight.TabIndex = 1;
            this.lbWeight.Text = "藥劑調配系統";
            // 
            // gbControl
            // 
            this.gbControl.Controls.Add(this.lbnum1);
            this.gbControl.Controls.Add(this.btnConnect);
            this.gbControl.Controls.Add(this.lbTime);
            this.gbControl.Controls.Add(this.lbStatus);
            this.gbControl.Controls.Add(this.lbnum);
            this.gbControl.Controls.Add(this.lbTotal);
            this.gbControl.Controls.Add(this.btnAdd);
            this.gbControl.Controls.Add(this.lbCurrentWeight);
            this.gbControl.Font = new System.Drawing.Font("標楷體", 14.2F, System.Drawing.FontStyle.Bold);
            this.gbControl.Location = new System.Drawing.Point(86, 122);
            this.gbControl.Name = "gbControl";
            this.gbControl.Size = new System.Drawing.Size(843, 431);
            this.gbControl.TabIndex = 2;
            this.gbControl.TabStop = false;
            this.gbControl.Text = "藥劑控制板 ";
            this.gbControl.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lbnum1
            // 
            this.lbnum1.AutoSize = true;
            this.lbnum1.Font = new System.Drawing.Font("標楷體", 20F, System.Drawing.FontStyle.Bold);
            this.lbnum1.Location = new System.Drawing.Point(395, 374);
            this.lbnum1.Name = "lbnum1";
            this.lbnum1.Size = new System.Drawing.Size(261, 34);
            this.lbnum1.TabIndex = 6;
            this.lbnum1.Text = "最新更新時間 :";
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.Color.Red;
            this.btnConnect.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.Location = new System.Drawing.Point(640, 22);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(189, 57);
            this.btnConnect.TabIndex = 7;
            this.btnConnect.Text = "OFF";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // lbTime
            // 
            this.lbTime.AutoSize = true;
            this.lbTime.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold);
            this.lbTime.Location = new System.Drawing.Point(678, 378);
            this.lbTime.Name = "lbTime";
            this.lbTime.Size = new System.Drawing.Size(141, 30);
            this.lbTime.TabIndex = 6;
            this.lbTime.Text = "20:20:38";
            // 
            // lbStatus
            // 
            this.lbStatus.AutoSize = true;
            this.lbStatus.Font = new System.Drawing.Font("標楷體", 28F, System.Drawing.FontStyle.Bold);
            this.lbStatus.ForeColor = System.Drawing.Color.Red;
            this.lbStatus.Location = new System.Drawing.Point(231, 259);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(167, 47);
            this.lbStatus.TabIndex = 5;
            this.lbStatus.Text = "未加入";
            // 
            // lbnum
            // 
            this.lbnum.AutoSize = true;
            this.lbnum.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnum.Location = new System.Drawing.Point(67, 259);
            this.lbnum.Name = "lbnum";
            this.lbnum.Size = new System.Drawing.Size(158, 45);
            this.lbnum.TabIndex = 4;
            this.lbnum.Text = "Status : ";
            // 
            // lbTotal
            // 
            this.lbTotal.AutoSize = true;
            this.lbTotal.Font = new System.Drawing.Font("標楷體", 30F, System.Drawing.FontStyle.Bold);
            this.lbTotal.Location = new System.Drawing.Point(405, 72);
            this.lbTotal.Name = "lbTotal";
            this.lbTotal.Size = new System.Drawing.Size(48, 50);
            this.lbTotal.TabIndex = 2;
            this.lbTotal.Text = "0";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Gold;
            this.btnAdd.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Location = new System.Drawing.Point(248, 159);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(260, 60);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "加入藥劑 5 g ";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lbCurrentWeight
            // 
            this.lbCurrentWeight.AutoSize = true;
            this.lbCurrentWeight.Font = new System.Drawing.Font("標楷體", 20F, System.Drawing.FontStyle.Bold);
            this.lbCurrentWeight.Location = new System.Drawing.Point(69, 86);
            this.lbCurrentWeight.Name = "lbCurrentWeight";
            this.lbCurrentWeight.Size = new System.Drawing.Size(296, 34);
            this.lbCurrentWeight.TabIndex = 0;
            this.lbCurrentWeight.Text = "目前已加入總量 :";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 602);
            this.Controls.Add(this.gbControl);
            this.Controls.Add(this.lbWeight);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gbControl.ResumeLayout(false);
            this.gbControl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbWeight;
        private System.Windows.Forms.GroupBox gbControl;
        private System.Windows.Forms.Label lbCurrentWeight;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.Label lbnum;
        private System.Windows.Forms.Label lbTotal;
        private System.Windows.Forms.Label lbTime;
        private System.Windows.Forms.Label lbnum1;
        private System.Windows.Forms.Button btnConnect;
        public System.Windows.Forms.Timer timer1;
    }
}

