﻿using EasyModbus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FinalProject
{
    public partial class Form1 : Form
    {
        //ModbusClient modClient = new ModbusClient("172.20.10.2", 502) ;
        ModbusClient modClient = new ModbusClient("192.168.0.108", 502);

        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            
            if (btnConnect.Text == "OFF") // disconnect
            {
                modClient.Connect();
                timer1.Enabled = true;
                if (modClient != null && modClient.Connected)
                {
                    btnConnect.Text = "ON"; // connect
                    btnConnect.BackColor = Color.Green;
                }

            }
            else if( btnConnect.Text == "ON" && modClient.Connected)
            {
                int address = 0; // 40009
                modClient.WriteSingleRegister(address, 0 );
                timer1.Enabled = false;
                modClient.Disconnect();
                modClient = null;
                btnConnect.Text = "OFF";
                btnConnect.BackColor = Color.Red;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            int currentValue = modClient.ReadHoldingRegisters(0, 1)[0];
            lbTotal.Text = $"{currentValue} g";
            lbStatus.Text = "未加入" ;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(modClient.Connected)
            {
                int address = 0; // 40009
                int currentValue = modClient.ReadHoldingRegisters(address, 1)[0];
                int newValue = currentValue + 5 ;

                modClient.WriteSingleRegister(address, newValue);
                lbStatus.Text = "加入完畢 (+5g)";
                lbTime.Text = DateTime.Now.ToString("HH:mm:ss") ;

            }             

        }
    }
}
